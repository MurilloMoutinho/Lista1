﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nbase;
            double altura;
            double resultado;

            Console.WriteLine("Digite a valor da base: ");
            nbase = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.WriteLine("Digite o valor da altura: ");
            altura = double.Parse(Console.ReadLine());
            Console.WriteLine();

            resultado = nbase * altura / 2;
            Console.WriteLine("o resulrtado da sua conta é: {0} ", resultado);



        }
    }
}
