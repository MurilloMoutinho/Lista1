﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1Ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nbase;
            double altura;
            double resultado;

            Console.WriteLine("Digite valor da base");
            nbase=double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor da altura");
            altura=double.Parse(Console.ReadLine());

            resultado = nbase * altura;

            Console.WriteLine("resultado é {0}", resultado);
        }
    }
}
