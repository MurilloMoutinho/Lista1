﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1EX3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double diagonal;
            double lado;
            double resultado;

            Console.WriteLine("EXERCICIO 3 DA LISTA 1");
            Console.WriteLine("");

            Console.WriteLine("digite o valor da diagonal: ");
            diagonal = double.Parse(Console.ReadLine());

            lado = diagonal / Math.Sqrt(2);
            resultado = lado / Math.Pow(lado, 2);

            Console.WriteLine("resultado: {0}",resultado);
        }
    }
}
