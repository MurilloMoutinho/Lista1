﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.Write("Digite um valor em Graus Celsius: ");
            valor = double.Parse(Console.ReadLine());
            resultado = (valor * 1.8) + 32;
            Console.WriteLine();

            Console.WriteLine("Resultado em Fahrenheit: {0}", resultado);
            Console.WriteLine();

        }
    }
}
