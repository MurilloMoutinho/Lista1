﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;
            double resultado;

            Console.Write("Digite o Valor do Diâmetro do Circulo: ");
            valor = double.Parse(Console.ReadLine());
            resultado = Math.PI * Math.Pow((valor / 2), 2);
            Console.WriteLine();

            Console.WriteLine("Resultado: {0}", resultado);
            Console.WriteLine();
        }
    }
}
