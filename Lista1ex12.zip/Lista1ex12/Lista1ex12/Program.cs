﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista1ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valorp1;
            double valorp2;
            double valorp3;
            double valorp4;
            double valorp5;
            double pagamento;
            double troco;

           
            Console.Write("Digite o Valor do Primeiro Produto: R$ ");
            valorp1 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o Valor do Segundo Produto: R$ ");
            valorp2 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o Valor do Terceiro Produto: R$ ");
            valorp3 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o Valor do Quarto Produto: R$ ");
            valorp4 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o Valor do Quinto Produto: R$ ");
            valorp5 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Digite o Valor do Pagamento: R$ ");
            pagamento = double.Parse(Console.ReadLine());
            Console.WriteLine();

            troco = pagamento - (valorp1 + valorp2 + valorp3 + valorp4 + valorp5);
            Console.WriteLine("Troco: {0}", troco.ToString("C"));
            Console.WriteLine();
        }
    }
}
